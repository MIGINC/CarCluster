#pragma once

#define MG_ARCH MG_ARCH_ESP32
#define MG_OTA MG_OTA_ESP32
#define MG_ENABLE_PACKED_FS 1
